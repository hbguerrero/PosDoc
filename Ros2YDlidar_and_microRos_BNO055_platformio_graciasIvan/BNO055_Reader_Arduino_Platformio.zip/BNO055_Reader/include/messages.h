#ifndef MESSAGES_H
#define MESSAGES_H

#include <Arduino.h>

/*CONSTANTES*/
#define COMMAND_ALL_DATA 0x00
#define START_SEQUENCE 0x0A

typedef struct __attribute__((packed)) {
    uint8_t start = START_SEQUENCE;
    uint8_t command;
    /*SENSOR_TYPE_ORIENTATION*/
    float orientation_x = NAN;
    float orientation_y = NAN;
    float orientation_z = NAN;
    /*SENSOR_TYPE_ACCELEROMETER*/
    float acceleration_x = NAN;
    float acceleration_y = NAN;
    float acceleration_z = NAN;
    /*SENSOR_TYPE_MAGNETIC_FIELD*/
    float magnetic_x = NAN;
    float magnetic_y = NAN;
    float magnetic_z = NAN;
    /*SENSOR_TYPE_GYROSCOPE*/
    float gyro_x = NAN;
    float gyro_y = NAN;
    float gyro_z = NAN;
    /*SYSTEM*/
    uint8_t temp;
    uint8_t cal_sys;
    uint8_t cal_gyro;
    uint8_t cal_accel;
    uint8_t cal_mag;

} message_t ;

typedef struct {
    uint8_t start = 0xAA;
    uint8_t command;
} command_t;

#endif  // SERIAL_COMMANDS_H