#ifndef MAIN_H
#define MAIN_H

#include <Arduino.h>
#include <Adafruit_Sensor.h>

void setData(sensors_event_t* event);
void readCommand();
#endif