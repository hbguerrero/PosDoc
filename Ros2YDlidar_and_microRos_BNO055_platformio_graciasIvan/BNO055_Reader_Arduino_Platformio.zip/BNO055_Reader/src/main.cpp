#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BNO055.h>
#include <utility/imumaths.h>

#include "main.h"
#include "messages.h"

#define LED 2

/* Set the delay between fresh samples */
uint16_t BNO055_SAMPLERATE_DELAY_MS = 100;

// Check I2C device address and correct line below (by default address is 0x29 or 0x28)
//                                   id, address
Adafruit_BNO055 bno = Adafruit_BNO055(55, 0x28, &Wire);

message_t msg;
command_t *receivedCommand = nullptr;  // Puntero a la estructura

bool isReadingData = false;
bool isSendingData = false;

void setup(void)
{
  pinMode(LED,OUTPUT);
  digitalWrite(LED,LOW);
  Serial.begin(115200);
  while (!Serial) delay(10);  // wait for serial port to open!
  if (!bno.begin())
  {
    while (1){
      delay(250);
      digitalWrite(LED,HIGH);
      delay(250);
      digitalWrite(LED,LOW);
    };
  }
  delay(1000);
  digitalWrite(LED,HIGH);
}

void loop(void)
{
  sensors_event_t orientationData , angVelocityData , linearAccelData, magnetometerData, accelerometerData, gravityData;
  bno.getEvent(&orientationData, Adafruit_BNO055::VECTOR_EULER);
  setData(&orientationData);
  bno.getEvent(&angVelocityData, Adafruit_BNO055::VECTOR_GYROSCOPE);
  setData(&angVelocityData);
  bno.getEvent(&linearAccelData, Adafruit_BNO055::VECTOR_LINEARACCEL);
  setData(&linearAccelData);
  bno.getEvent(&magnetometerData, Adafruit_BNO055::VECTOR_MAGNETOMETER);
  setData(&magnetometerData);
  bno.getEvent(&accelerometerData, Adafruit_BNO055::VECTOR_ACCELEROMETER);
  setData(&accelerometerData);
  bno.getEvent(&gravityData, Adafruit_BNO055::VECTOR_GRAVITY);
  setData(&gravityData);
  msg.temp = bno.getTemp();
  uint8_t system, gyro, accel, mag = 0;
  bno.getCalibration(&system, &gyro, &accel, &mag);
  msg.cal_sys = system;
  msg.cal_gyro = gyro;
  msg.cal_mag = mag;
  msg.cal_accel = accel;
  readCommand();
}

void setData(sensors_event_t* event) {
  if (event->type == SENSOR_TYPE_ACCELEROMETER) {
    msg.acceleration_x = event->acceleration.x;
    msg.acceleration_y = event->acceleration.y;
    msg.acceleration_z = event->acceleration.z;
  }
  else if (event->type == SENSOR_TYPE_ORIENTATION) {
    msg.orientation_x = event->orientation.x;
    msg.orientation_y = event->orientation.y;
    msg.orientation_z = event->orientation.z;
  }
  else if (event->type == SENSOR_TYPE_MAGNETIC_FIELD) {
    msg.magnetic_x = event->magnetic.x;
    msg.magnetic_y = event->magnetic.y;
    msg.magnetic_z = event->magnetic.z;
  }
  else if (event->type == SENSOR_TYPE_GYROSCOPE) {
    msg.gyro_x = event->gyro.x;
    msg.gyro_y = event->gyro.y;
    msg.gyro_z = event->gyro.z;
  }
}


void readCommand() {
  if (Serial.available()) { 
      while(Serial.available()){Serial.read();}
      msg.command = COMMAND_ALL_DATA;
      Serial.write((uint8_t*)&msg, sizeof(msg));
    } 
}